# Streamlining IT Procurement: Automating Standard Laptop Orders with Flow Designer

**Team ID:** SWTID-2026-8854

## Project Overview
This project automates the standard laptop procurement/request lifecycle using ServiceNow Flow Designer.

## Workflow
Employee Request → Laptop Catalog Item → Approval → Fulfillment Task → Status Update → Notification

## Technology
- ServiceNow
- Service Catalog
- Flow Designer
- ServiceNow request/task records
- Approval workflow
- Notifications
- Roles and ACLs

## Repository Structure
- `01_Ideation/` – empathy map, problem statements, brainstorming
- `02_Requirement_Analysis/` – requirements, DFD, user stories, technology stack, journey map
- `03_Project_Design/` – solution fit, proposed solution, architecture
- `04_Project_Planning/` – sprint planning and planning logic
- `05_Testing/` – UAT and functional/performance testing
- `06_Documentation/` – FSD and final project report
- `07_Diagrams/` – project diagrams
- `evidence/screenshots/` – actual ServiceNow screenshots to be added
- `evidence/demo/` – optional demo recording/link to be added

## Evidence
Screenshots and recordings are intentionally not fabricated. Actual ServiceNow evidence can be added after the project demo is recorded.

## Team
**Team ID:** SWTID-2026-8854
